# Booklet Maker

A starter web application that converts a regular PDF into an A4 landscape booklet layout.

## Features in this first version

- Upload a PDF (up to 100 MB).
- Single-bundle mode.
- Multiple-signature mode (8, 16, 24, 32 or 40 book pages per signature).
- A4 landscape output with two original pages on each side.
- Adds blank positions automatically when a signature is not full.
- Mobile-friendly upload interface.

## Run locally

Requires Node.js 18 or newer.

```bash
npm install
npm start
```

Open `http://localhost:3000`.

## Deploy to Render

1. Upload these files to a GitHub repository.
2. In Render, choose **New + → Web Service** and connect the repository.
3. Use these settings:
   - Runtime: Node
   - Build Command: `npm install`
   - Start Command: `npm start`
4. Deploy. Render supplies the `PORT` environment variable automatically.

## Important printing notes

- Output pages are A4 landscape.
- Each output PDF page is one side of an A4 sheet.
- Print double-sided at actual size / 100%.
- Test one signature before printing the entire book.
- The correct duplex flip setting depends on the printer. Check that the back side is upright after folding.
- This starter version does not compensate for paper creep, add a cover, or detect printer-specific non-printable margins.
- Password-protected PDFs are not supported.
- Very large PDFs may exceed the memory available on a small hosting instance.

## Privacy

Uploaded PDFs are processed in server memory and are not intentionally saved to disk. The hosting provider may still process request data under its own infrastructure and logging policies. Do not upload confidential documents until you have reviewed your hosting provider's privacy and retention terms.

## Next improvements

- Browser-side PDF processing for private/offline use.
- Front/back preview.
- Manual duplex print mode with separate front and back downloads.
- Printer-specific flip-edge setting.
- Creep compensation for thicker signatures.
- Configurable signature size and binding margin.
