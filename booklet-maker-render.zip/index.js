const express = require("express");
const multer = require("multer");
const { PDFDocument } = require("pdf-lib");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const MAX_FILE_SIZE = 100 * 1024 * 1024; // 100 MB

app.use(express.static(path.join(__dirname, "public")));

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: MAX_FILE_SIZE, files: 1 },
  fileFilter: (req, file, cb) => {
    const isPdf =
      file.mimetype === "application/pdf" ||
      file.originalname.toLowerCase().endsWith(".pdf");
    cb(isPdf ? null : new Error("Please upload a PDF file."), isPdf);
  }
});

const A4_LANDSCAPE = {
  width: 841.89,  // points
  height: 595.28
};

function roundUpToMultiple(value, multiple) {
  return Math.ceil(value / multiple) * multiple;
}

/*
 * Returns the page numbers for one folded signature.
 * Page numbers here are zero-based.
 *
 * Example for 4 pages:
 * Front: [3, 0]
 * Back:  [1, 2]
 */
function getSignatureSheets(pageCount) {
  const paddedCount = roundUpToMultiple(pageCount, 4);
  const sheets = [];

  for (let sheet = 0; sheet < paddedCount / 4; sheet++) {
    sheets.push({
      front: [paddedCount - 1 - (2 * sheet), 2 * sheet],
      back: [2 * sheet + 1, paddedCount - 2 - (2 * sheet)]
    });
  }

  return { paddedCount, sheets };
}

function fitPageIntoHalf(sourcePage, targetPage, x, y, halfWidth, halfHeight, margin) {
  const availableWidth = halfWidth - margin * 2;
  const availableHeight = halfHeight - margin * 2;
  const sourceSize = sourcePage.getSize();

  const scale = Math.min(
    availableWidth / sourceSize.width,
    availableHeight / sourceSize.height
  );

  const width = sourceSize.width * scale;
  const height = sourceSize.height * scale;

  targetPage.drawPage(sourcePage, {
    x: x + (halfWidth - width) / 2,
    y: y + (halfHeight - height) / 2,
    width,
    height
  });
}

async function makeBooklet(inputBytes, options) {
  const sourcePdf = await PDFDocument.load(inputBytes, {
    ignoreEncryption: false
  });

  const sourcePages = sourcePdf.getPages();
  const totalPages = sourcePages.length;

  if (totalPages === 0) {
    throw new Error("The uploaded PDF has no pages.");
  }

  const mode = options.mode === "signatures" ? "signatures" : "single";
  const marginMm = Math.max(0, Math.min(Number(options.marginMm) || 8, 25));
  const margin = marginMm * 72 / 25.4;

  // In signature mode, this is the number of book pages per folded section.
  // Must be a multiple of four. Default: 16 pages (4 sheets).
  let signatureSize = Number(options.signatureSize) || 16;
  signatureSize = Math.max(4, Math.min(128, Math.round(signatureSize / 4) * 4));

  const groups = [];
  if (mode === "single") {
    groups.push({ start: 0, count: totalPages });
  } else {
    for (let start = 0; start < totalPages; start += signatureSize) {
      groups.push({
        start,
        count: Math.min(signatureSize, totalPages - start)
      });
    }
  }

  const outputPdf = await PDFDocument.create();
  const halfWidth = A4_LANDSCAPE.width / 2;
  const halfHeight = A4_LANDSCAPE.height;

  // Embed from the original PDF bytes into the output document.
  const embeddedSourcePages = await outputPdf.embedPdf(inputBytes);

  for (const group of groups) {
    const { paddedCount, sheets } = getSignatureSheets(group.count);

    // Missing page slots remain blank; real pages reuse the embedded originals.
    for (const sheet of sheets) {
      for (const side of ["front", "back"]) {
        const outputPage = outputPdf.addPage([
          A4_LANDSCAPE.width,
          A4_LANDSCAPE.height
        ]);

        const positions = sheet[side]; // [left page, right page]
        positions.forEach((localPageNumber, index) => {
          if (localPageNumber < 0 || localPageNumber >= group.count) return;

          const embeddedPage = embeddedSourcePages[group.start + localPageNumber];
          const x = index === 0 ? 0 : halfWidth;

          fitPageIntoHalf(
            embeddedPage,
            outputPage,
            x,
            0,
            halfWidth,
            halfHeight,
            margin
          );
        });
      }
    }
  }

  outputPdf.setTitle("Booklet PDF");
  outputPdf.setSubject("A4 landscape booklet imposition");
  outputPdf.setCreator("Booklet Maker");
  return {
    bytes: await outputPdf.save(),
    inputPages: totalPages,
    outputSheets: outputPdf.getPageCount() / 2,
    outputSides: outputPdf.getPageCount(),
    mode
  };
}

app.get("/api/health", (req, res) => {
  res.json({ ok: true, service: "Booklet Maker" });
});

app.post("/api/convert", upload.single("pdf"), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: "Choose a PDF file first." });
    }

    const result = await makeBooklet(req.file.buffer, {
      mode: req.body.mode,
      signatureSize: req.body.signatureSize,
      marginMm: req.body.marginMm
    });

    const filename = "booklet-ready.pdf";
    res.setHeader("Content-Type", "application/pdf");
    res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);
    res.setHeader("X-Input-Pages", String(result.inputPages));
    res.setHeader("X-Output-Sheets", String(result.outputSheets));
    res.send(Buffer.from(result.bytes));
  } catch (error) {
    console.error(error);
    const message = error.message.includes("encrypted")
      ? "This PDF appears to be password-protected. Remove the password and try again."
      : error.message || "Could not convert this PDF.";
    res.status(400).json({ error: message });
  }
});

app.use((error, req, res, next) => {
  if (error instanceof multer.MulterError && error.code === "LIMIT_FILE_SIZE") {
    return res.status(413).json({ error: "The file is too large. Maximum size is 100 MB." });
  }
  res.status(400).json({ error: error.message || "Upload failed." });
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`Booklet Maker running on port ${PORT}`);
});
